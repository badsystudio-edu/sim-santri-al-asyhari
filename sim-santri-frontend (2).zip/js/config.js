// ISI dengan URL Web App Apps Script Anda (diakhiri /exec).
// Contoh: https://script.google.com/macros/s/AKfycb.../exec
const GAS_URL = "TEMPEL_URL_WEB_APP_ANDA_DI_SINI";

const APP_INFO = {
  nama: "SIM Santri",
  lembaga: "Pesantren Tahfidz Al Asyhari",
  lokasi: "Rogojampi, Banyuwangi"
};
